package com.capgemini.wallet.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.wallet.wservice.ValidateInfo;
public class ValidationTest 
{
	
	//@Test
	public void FNameOnlyChar()
	{
		
		boolean actualReturnValue1 = 
				ValidateInfo.validateFirstName("Ravali");
		assertEquals(true, actualReturnValue1);
		
	}
	
	//@Test
	public void LNameOnlyChar()
	{
		boolean actualReturnValue2 = 
				ValidateInfo.validateLastName("madireddy");
		assertEquals(false, actualReturnValue2);
	}

	//@Test
	public void ContactOnlyNum()
	{
		boolean actualReturnValue3 =
				ValidateInfo.validateContact("78787878");
		assertEquals(false, actualReturnValue3);
	}
	
	
	@Test
	public void EmailPatternFollowed()
	{
		boolean actualReturnValue4 =
				ValidateInfo.validateEmail(".m.k_rav%ali09@gmail.com");
		assertEquals(false,actualReturnValue4);
	}
	
	//@Test
	public void UserIdMaintained()
	{
		boolean actualReturnValue5 =
				ValidateInfo.validateUserID("Mine#56");
		assertEquals(false,actualReturnValue5);
	}
	
	//@Test
	public void PasswordValid()
	{
		boolean actualReturnValue6 =
				ValidateInfo.validatePassword("thinin#17");
		assertEquals(false,actualReturnValue6);
	}
	
	//@Test
	public void AccountValid()
	{
		boolean actualReturnValue7 =
				ValidateInfo.validateAccountNo("567354792637568");
		assertEquals(true,actualReturnValue7);
	}
	
	//@Test
	public void AccountInValid()
	{
		boolean actualReturnValue7 =
				ValidateInfo.validateAccountNo("5675479268");
		assertEquals(false,actualReturnValue7);
	}
	
	//@Test
	public void pinValid()
	{
		boolean actualReturnValue8=
				ValidateInfo.validatePin("6739");
		assertEquals(true,actualReturnValue8);
				
	}
	
	

}
