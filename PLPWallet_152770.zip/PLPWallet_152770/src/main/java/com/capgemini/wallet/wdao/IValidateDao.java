package com.capgemini.wallet.wdao;



import com.capgemini.wallet.userbean.UserBean;
import com.capgemini.wallet.wexception.WalletException;

public interface IValidateDao {
	public int addUserDetails(UserBean user);
	public UserBean getUserDetails(String UserId) throws WalletException;

}
