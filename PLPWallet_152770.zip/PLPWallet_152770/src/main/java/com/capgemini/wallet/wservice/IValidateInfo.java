package com.capgemini.wallet.wservice;

import java.util.ArrayList;

import com.capgemini.wallet.userbean.UserBean;
import com.capgemini.wallet.wexception.WalletException;

public interface IValidateInfo {
	UserBean getUserDetails(String uidname) throws WalletException;

	int addUserDetails(UserBean user);
	
	boolean loginCredentials(UserBean person , String pwd);
	
	int balanceCheck(UserBean person);
	
	int deposit(UserBean person, int amount);
	
	int withDraw(UserBean person,int amt);

	int fundTransfer(UserBean sender,UserBean receiver,int Amt);
	

}
