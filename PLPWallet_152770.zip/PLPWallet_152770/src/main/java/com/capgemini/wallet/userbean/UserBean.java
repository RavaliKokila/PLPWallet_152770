package com.capgemini.wallet.userbean;

import java.util.ArrayList;

public class UserBean {

	private String FirstName;
	private String LastName;
	private String Email;
	private String ContactNo;
	private String UserID;
	private String Password;
	private String AccNo;
	private int Balance;
	ArrayList <StringBuilder> printTrans=new ArrayList<StringBuilder>();
	
	public ArrayList<StringBuilder> getPrintTrans() {
		return printTrans;
	}
	public void setPrintTrans(StringBuilder printTrans) {
		this.printTrans.add(printTrans);
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getContactNo() {
		return ContactNo;
	}
	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}
	public String getUserID() {
		return UserID;
	}
	@Override
	public String toString() {
		return "UserBean [FirstName=" + FirstName + ", LastName=" + LastName
				+ ", Email=" + Email + ", ContactNo=" + ContactNo + ", UserID="
				+ UserID + ", Password=" + Password + "]";
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getAccNo() {
		return AccNo;
	}
	public void setAccNo(String accNo) {
		AccNo = accNo;
	}
	public int getBalance() {
		return Balance;
	}
	public void setBalance(int balance) {
		Balance = balance;
	}
}
