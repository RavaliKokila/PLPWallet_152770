package com.capgemini.wallet.wdao;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.wallet.userbean.UserBean;
import com.capgemini.wallet.wexception.WalletException;


	public class ValidateDao implements IValidateDao{
		UserBean ub=new UserBean();
		Map<String,UserBean> data=new HashMap<String,UserBean>();
		//String userID= ub.getUserID();

		Date date=new Date();
		@Override
		
		public int addUserDetails(UserBean user) {
			// TODO Auto-generated method stub
			//if(user.getUserID()==data.)
		
			data.put(user.getUserID(),user);
			System.out.println(data);
			return 0;		
		}
		
		@Override
		public UserBean getUserDetails(String UserId) throws WalletException {
			// TODO Auto-generated method stub
			UserBean ub=data.get(UserId);
			if(ub==null)
				throw new WalletException("Requested user id "+UserId+" doesnt exist");
			return ub;
		}

	

}
