package com.capgemini.wallet.wservice;

import com.capgemini.wallet.userbean.UserBean;
import com.capgemini.wallet.wdao.IValidateDao;
import com.capgemini.wallet.wexception.WalletException;

public class ValidateInfo {

	IValidateDao vf;
	UserBean ub;
	
	static String namePattern="[A-Z]{1}[a-z]{2,}";
	static String contactPattern = "[0-9]{10}";
	static String emailPattern = "[A-Z | a-z | 0-9 |.|_|@]{10,}";
	static String userIDPattern = "[A-Z | a-z |0-9]{6,10}";
	static String AccNoPattern = "[0-9]{15}";
	static String PinPattern= "[0-9]{4}";
	
	public int addUserDetails(UserBean user) {
		// TODO Auto-generated method stub
		return vf.addUserDetails(user);
	}


	public UserBean getUserDetails(String uidname) throws WalletException{
		// TODO Auto-generated method stub
		return vf.getUserDetails(uidname);
	}
	
	public boolean loginCredentials(UserBean person, String pwd) {
		//return vf.loginCredentials(UserId, pwd);
		boolean check=false;
		if(person.getPassword().matches(pwd))
		{
			check=true;
		}	
		return check;
	}
	
	
	public int balanceCheck(UserBean person) {
		//return vf.balanceCheck(AccNo);
		return person.getBalance();
	}
	
	
	public int withDraw(UserBean person,int amt){
		//return vf.withDraw(userid,amt);
		int currentbal=person.getBalance()-amt;
		return currentbal;
	}
	
	public int fundTransfer(UserBean person,UserBean person3,int Amt){
		//return vf.fundTransfer(senderId,receiverId,Amt);
		//UserBean ub4=data.get(senderId);
		//UserBean ub5=data.get(receiverId);
		int receiverBal=person3.getBalance()+Amt;
		person3.setBalance(receiverBal);
		int senderBal=person.getBalance()-Amt;
		person.setBalance(senderBal);
		return senderBal;
	}
	

	
	public static boolean validateFirstName(String FName) {
		// TODO Auto-generated method stub
		
		boolean flag = false;
		if(FName.matches(namePattern))
		{
			flag = true;
		}

		return flag;
		
	}


	public static boolean validateLastName(String LName) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(LName.matches(namePattern))
		{
			flag = true;
		}
		return flag;
	}


	public static boolean validateContact(String Number) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(Number.matches(contactPattern))
		{
			flag = true;
		}
		return flag;

	}


	public static boolean validateEmail(String MailID) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if((MailID.matches(emailPattern)) && (!MailID.matches("[.|_]{1}")))
		{
			flag = true;
		}
		//if(!MailID.matches("[.|_]{1}"))
			//flag = true;
		return flag;

	}


	public static boolean validateUserID(String UserID) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(UserID.matches(userIDPattern))
		{
			flag = true;
		}
		return flag;
		
	}


	public static boolean validatePassword(String pwd) {
		// TODO Auto-generated method stub
	
		boolean flag=true;
			if(!pwd.matches("(.*[A-Z].*)"))
			{
				System.out.println("Atleast one upper case letter is required");
				flag=false;
			}
			if(!pwd.matches("(.*[a-z].*)"))
			{
				System.out.println("Atleat one lower case letter is required");
				flag=false;
			}
			if(!pwd.matches("(.*[0-9].*)"))
			{
				System.out.println("Atleat one digit is required");
				flag=false;
			}
			if(!pwd.matches("(.*[!@#$%].*)"))
			{
				System.out.println("Atleat one special character is required");
				flag=false;
			}
			
		return flag;
		
	}


	public static boolean validateAccountNo(String AccNo) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(AccNo.matches(AccNoPattern))
		{
			flag = true;
		}
		return flag;
		
	}


	public static boolean validatePin(String Pin) {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		if(Pin.matches(PinPattern))
		{
			flag = true;
		}
		return flag;
		
	}


	public int deposit(UserBean person, int depositvalue) {
		// TODO Auto-generated method stub
		int newbal=person.getBalance()+depositvalue;
		return newbal;
		//return 0;
	}


}
