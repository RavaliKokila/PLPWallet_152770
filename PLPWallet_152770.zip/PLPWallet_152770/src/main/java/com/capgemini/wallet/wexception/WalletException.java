package com.capgemini.wallet.wexception;

public class WalletException extends Exception {

	String message;
	
	public WalletException(String msg)
	{
		message=msg;
	}
	
	public String getMessage()
	{
		return message;
	}
}
